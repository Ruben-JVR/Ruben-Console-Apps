﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Ruben JVR
 * 2022-11-14
 * Madlib Part 2
 * */
namespace RJVR_Madlib_Part2
{
    class Program
    {
        static void Main()
        {
            Program game = new Program();
            Madlib.Run();
        }
    }

    static class Madlib
    {
        static string bodyPart1;
        static string adjective1;
        static string noun1;
        static string bodyPart2;
        static string noun2;
        static string bodyPart3;
        static string verb1;
        static string bodyPart4;
        static string bodyPart5;
        static string verb2;
        static string bodyPart6;
        static string adjective2;
        static string noun3;
        static string verb3;
        static string adjective3;
        static string bodyPart7;
        static string verb4;
        static string levelOfIntensity;
        static string story;

        public static void Run()
        {
            string title = @" _____ ______   ________  ________  ___       ___  ________           _______     
|\   _ \  _   \|\   __  \|\   ___ \|\  \     |\  \|\   __  \         /  ___  \    
\ \  \\\__\ \  \ \  \|\  \ \  \_|\ \ \  \    \ \  \ \  \|\ /_       /__/|_/  /|   
 \ \  \\|__| \  \ \   __  \ \  \ \\ \ \  \    \ \  \ \   __  \      |__|//  / /   
  \ \  \    \ \  \ \  \ \  \ \  \_\\ \ \  \____\ \  \ \  \|\  \         /  /_/__  
   \ \__\    \ \__\ \__\ \__\ \_______\ \_______\ \__\ \_______\       |\________\
    \|__|     \|__|\|__|\|__|\|_______|\|_______|\|__|\|_______|        \|_______|
                                                                                  ";

            //declare variables


            Console.WriteLine(title);

            Console.WriteLine("-------");
            Console.WriteLine("Madlib!");
            Console.WriteLine("-------");

            //ask player to enter words
            sendOut("Please enter a body part.\n");
            bodyPart1 = getIn();
            sendOut("Please enter a Adjective.\n");
            adjective1 = getIn();
            sendOut("Please enter a Noun.\n");
            noun1 = getIn();
            sendOut("Please enter a body part.\n");
            bodyPart2 = getIn();
            sendOut("Please enter a Noun\n");
            noun2 = getIn();
            sendOut("Please enter a body part.\n");
            bodyPart3 = getIn();
            sendOut("Please enter a verb ending in s.\n");
            verb1 = getIn();
            sendOut("Please enter a body part.\n");
            bodyPart4 = getIn();
            sendOut("Please enter a body part.\n");
            bodyPart5 = getIn();
            sendOut("Please enter a verb.\n");
            verb2 = getIn();
            sendOut("Please enter a body part.\n");
            bodyPart6 = getIn();
            sendOut("Please enter a Adjective.\n");
            adjective2 = getIn();
            sendOut("Please enter a Noun.\n");
            noun3 = getIn();
            sendOut("Please enter a verb ending in s\n");
            verb3 = getIn();
            sendOut("Please enter a Adjective.\n");
            adjective3 = getIn();
            sendOut("Please enter a body part.\n");
            bodyPart7 = getIn();
            sendOut("Please enter a verb ending in s\n");
            verb4 = getIn();
            sendOut("Please enter a level of intensity\n");
            levelOfIntensity = getIn();


            //write out finished story

            story = "Suddenly he grabs me, tipping me across his "+bodyPart1+". With one "+adjective1+" movement, he angles his "+noun1+" so my "+bodyPart2+" is resting on the "+noun2+" beside him. He throws his right "+bodyPart3+" over mine and "+verb1+" his left "+bodyPart4+" on the top of my "+bodyPart5+" holding me down so i cannot "+verb2+"... He places his "+bodyPart6+" on my "+adjective2+" "+noun3+", softly "+ verb3+" me, stroking around and around with his "+adjective3+" palm. And then his "+bodyPart7+" is no longer there... and he "+verb4+" me "+levelOfIntensity;
            Console.WriteLine(story);

            //keep window open and prompt for a exit
            Console.WriteLine("Press any button to close the program");
            Console.ReadKey();
        }

        private static void sendOut(string str)
        {
            Console.Write(str);
        }

        private static string getIn()
        {
            return Console.ReadLine();
        }
    }
}

﻿using System;

namespace RJVR_Madlib_Part_1
{
    class Program
    {
        static void Main(string[] args)
        {

            //declare variables
            string Creature;
            string Luminous;
            string Ghastly;
            string spectral;
            string countryman;
            string farrier;
            string farmer;
            string dreadful;
            string apparition;
            string hound;
            string story;

            //write out a header and instructions
            string title = @"  _____       _                  __  __           _ _ _ _         
 |  __ \     | |                |  \/  |         | | (_) |        
 | |__) |   _| |__   ___ _ __   | \  / | __ _  __| | |_| |__  ___ 
 |  _  / | | | '_ \ / _ \ '_ \  | |\/| |/ _` |/ _` | | | '_ \/ __|
 | | \ \ |_| | |_) |  __/ | | | | |  | | (_| | (_| | | | |_) \__ \
 |_|  \_\__,_|_.__/ \___|_| |_| |_|  |_|\__,_|\__,_|_|_|_.__/|___/
                                                                  
                                                                  ";
            Console.WriteLine(title);

            Console.WriteLine("-------");
            Console.WriteLine("Madlib!");
            Console.WriteLine("-------");

            //ask player to enter words

            Console.Write("\nPlease enter a noun: \n");
            Creature = Console.ReadLine();
            Console.Write("\nPlease enter a adjective: \n");
            Luminous = Console.ReadLine();
            Console.Write("\nPlease enter a adjective: \n");
            Ghastly = Console.ReadLine();
            Console.Write("\nPlease enter a adjective: \n");
            spectral = Console.ReadLine();
            Console.Write("\nPlease enter a Occupation: \n");
            countryman = Console.ReadLine();
            Console.Write("\nPlease enter a Occupation: \n");
            farrier = Console.ReadLine();
            Console.Write("\nPlease enter a occupation: \n");
            farmer = Console.ReadLine();
            Console.Write("\nPlease enter a adjective: \n");
            dreadful = Console.ReadLine();
            Console.Write("\nPlease enter a noun: \n");
            apparition = Console.ReadLine();
            Console.Write("\nPlease enter a noun: \n");
            hound = Console.ReadLine();
            Console.Write("\n--------------\n");

            //write out finished story

            story = "They all agreed that it was a huge " + Creature + ", " + Luminous + ", " + Ghastly + ", and " + spectral + ". I have cross-examined these men, one of them a hard-headed " + countryman +
                ", one a " + farrier + ", and one a moorland " + farmer + ", who all tell the same story of this dreadful " + apparition + ", exactly corresponding to the hell-" + hound + " of the legend.";
            Console.WriteLine(story);

            //keep window open and prompt for a exit
            Console.WriteLine("Press any button to close the program");
            Console.ReadKey();
        }
    }
}
